require 'mkmf'

dir_config('sablot')

dir_config('iconv')
if with_config('iconv')
  have_library('iconv', 'iconv')
end

dir_config('expat')

## for old GCC like FreeBSD 3.3(without gcc295)
if with_config('oldgcc')
  have_library('gcc',nil)
end

if have_header("sablot.h") and
    ((have_library("expat",    "XML_ParserCreate") and
      have_library("expat",  "XmlParseXmlDecl")) or
     (have_library("xmltok", "XmlParseXmlDecl") and
      have_library("xmlparse", "XML_ParserCreate"))) and
    have_library("sablot", "SablotProcessStrings")
  create_makefile("sablot")
  STDERR.print <<EOB

  *** NOTICE ***
  If you use old GCC(ex. 2.7.2) and you can not
  install this library, you should use
  '--with-oldgcc' option.

EOB
else
  STDERR.print <<EOB

  Error Occured.

  You could use the following options:
    --with-sablot-dir=<sablot-dir>
    --with-iconv
    --with-iconv-dir=<iconv-dir>
    --with-expat-dir=<expat-dir>

EOB

end
