require 'sablot'

if ARGV.length != 2
  print "usage: ruby sample_obj.rb <xsl-file> <xml-file>\n"
  exit 1
end

xsl = open(ARGV[0]){|f| f.read}
xml = open(ARGV[1]){|f| f.read}

sab = Sablot.new()
sab.setLog("./sablot.log", 0)

arg = {"a"=>xsl, "b"=>xml}
sab.runProcessor("arg:/a", "arg:/b", "arg:/c", 
		    nil, 
		    arg)

print sab.resultArg("arg:/c")
