require 'sablot'

if ARGV.length != 2
  print "usage: ruby sample.rb <xsl-file> <xml-file>\n"
  exit 1
end

xsl = open(ARGV[0]){|f| f.read}
xml = open(ARGV[1]){|f| f.read}

print Sablot::process_strings(xsl, xml)
