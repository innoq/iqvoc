require 'sablot'

if ARGV.length != 2
  print "usage: ruby sample_param.rb sample_param.xsl <xml-file>\n"
  exit 1
end

xsl = open(ARGV[0]){|f| f.read}
xml = open(ARGV[1]){|f| f.read}

sab = Sablot.new()

arg = {"a"=>xsl, "b"=>xml}
param = {"address" => "by Takahashi 'Maki' Masayoshi (maki@rubycolor.org)"}
sab.runProcessor("arg:/a", "arg:/b", "arg:/c", 
		    param, 
		    arg)

print sab.resultArg("arg:/c")
