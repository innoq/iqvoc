require 'sablot'

if ARGV.length != 3
  print "usage: ruby sample_file.rb <xsl-file> <xml-file> <output-file>\n"
  exit 1
end

Sablot::process_files(ARGV[0], ARGV[1], ARGV[2])
