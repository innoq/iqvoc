require 'sablot'

if ARGV.length < 2 or ARGV.length > 3
  print "usage: ruby doc2html.rb <xsl-file> <xml-file> [encoding]\n"
  exit 1
end

xsl = open(ARGV[0]).read
xml = open(ARGV[1]).read
encoding = ARGV[2]

sab = Sablot.new()

if encoding
  sab.setEncoding(encoding)
end

arg = {"a"=>xsl, "b"=>xml}
sab.runProcessor("arg:/a", "arg:/b", "arg:/c", 
		    nil, 
		    arg)

print sab.resultArg("arg:/c")
