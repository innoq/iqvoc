require 'sablot'

xsl = <<"EOB"
<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns="http://www.w3.org/TR/xhtml1/strict">
<xsl:template match="/">
  <xsl:copy>
    <xsl:apply-templates />
  </xsl:copy>
</xsl:template>
</xsl:stylesheet>

EOB

xml = File.open('basic/sample.xml').read

sab = Sablot.new()

 def sab.messageError(code, level, ary)
   p ['messageError', code, level, ary]
 end

arg = {"a"=>xsl, "b"=>xml}
sab.runProcessor("arg:/a", "arg:/b", "arg:/c", 
		    nil, 
		    arg)

print sab.resultArg("arg:/c")
