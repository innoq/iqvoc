require 'sablot'

if ARGV.length != 2
  print "usage: ruby sample3.rb <xsl-file> <xml-file>\n"
  exit 1
end

class MySablot < Sablot

 def messageCode(code)
   p ['messageCode', code]
 end

 def messageLog(code, level, ary)
   p ['messageLog', code, level, ary]
 end

 def messageError(code, level, ary)
   p ['messageError', code, level, ary]
 end

end

xsl = open(ARGV[0]).read
xml = open(ARGV[1]).read

sab = MySablot.new()


arg = {"a"=>xsl, "b"=>xml}
sab.runProcessor("arg:/a", "arg:/b", "arg:/c", 
		    nil, 
		    arg)

print sab.resultArg("arg:/c")
